﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace PasswordEncryption
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("\t\t\t\t\t\tPASSWORD AUTHENTICATION SYSTEM\n------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("Please select one of the following:\n\n1. Establish an account\n2. Authenticate a user\n3. Exit the system\n\nEnter selection:");
            int caseSwitch = Int32.Parse(Console.ReadLine());

            string userName = "lmhart";
            string passWord = "Password";


            switch (caseSwitch)
            {
                case 1:
                    Account account = new Account();
                    account.AccountDetails();
                    Main();
                    break;
                case 2:
                    SignIn signIn = new SignIn();
                    signIn.LogIn(userName, passWord);
                    Main();
                    break;
                case 3:
                    Console.WriteLine("Ending program.");
                    break;
            }
        }
    }
}