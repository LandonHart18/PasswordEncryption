﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PasswordEncryption
{
    class SignIn
    {
        public void LogIn(string username, string passWord)
        {
            int loginAttempts = 0;

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Enter username:");
                string userName = Console.ReadLine();
                Console.WriteLine("Enter password:");
                string password = Console.ReadLine();

                if (username != "valid" || password != "valid")
                    loginAttempts++;
                else
                    break;
            }

            if (loginAttempts > 2)
                Console.WriteLine("Login failure");
            else
                Console.WriteLine("Login successful");

            Console.ReadKey();
        }
    }
}
